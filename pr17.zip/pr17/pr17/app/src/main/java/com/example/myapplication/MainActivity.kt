package com.example.myapplication

import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import org.w3c.dom.Text

class MainActivity : AppCompatActivity() {
    lateinit var login: EditText
    lateinit var pass: EditText
    lateinit var pref: SharedPreferences
    lateinit var textd: TextView
    public var twoname="name"
    public var twopass=""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        login = findViewById(R.id.login)
        pass = findViewById(R.id.pass)
        textd=findViewById(R.id.text)
    }
    fun handler(v: View) {
        if (v.id == R.id.save) {
            var name = login.getText().toString()
            var save = pref.edit()
            save.putString(twoname, name)
            save.apply()
            var names = pref.getString(twoname, "не определено")
            var passes=pref.getString(twopass,"не определено")
            textd.setText(names)

        }
        if (v.id == R.id.load) {
            pref = getPreferences(MODE_PRIVATE)
            var passes=pref.getString(twopass,"не определено")
            var names = pref.getString(twoname, "не определено")
            login.setText(names)
            textd.setText(names)
            pass.setText(passes)
        }
    }
}